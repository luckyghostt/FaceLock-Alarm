package com.facelock.alarm

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Face
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("facelock", MODE_PRIVATE) }
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(permissions.toTypedArray())

        setContent {
            val bg = Color(0xFF08111F)
            val card = Color(0xFF14243A)
            var hour by remember { mutableIntStateOf(prefs.getInt("hour", 7)) }
            var minute by remember { mutableIntStateOf(prefs.getInt("minute", 0)) }
            var pin by remember { mutableStateOf(prefs.getString("pin", "") ?: "") }
            var status by remember { mutableStateOf("No alarm scheduled") }
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF65D6FF), background = bg, surface = card)) {
                Surface(Modifier.fillMaxSize(), color = bg) {
                    Column(
                        Modifier.fillMaxSize().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        Spacer(Modifier.height(18.dp))
                        Icon(Icons.Rounded.Alarm, null, tint = Color(0xFF65D6FF), modifier = Modifier.size(42.dp))
                        Text("FaceLock", fontSize = 32.sp, color = Color.White)
                        Text("WAKE UP. PROVE YOU'RE AWAKE.", color = Color(0xFF9CB1C9), fontSize = 11.sp)
                        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(28.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(String.format(Locale.getDefault(), "%02d:%02d", hour, minute), fontSize = 58.sp, color = Color.White)
                                Text("Daily alarm", color = Color(0xFF9CB1C9))
                                Button(onClick = {
                                    TimePickerDialog(this@MainActivity, { _, h, m ->
                                        hour = h; minute = m
                                    }, hour, minute, true).show()
                                }) { Text("Choose alarm time") }
                            }
                        }
                        OutlinedTextField(
                            value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8); prefs.edit().putString("pin", pin).apply() },
                            label = { Text("Emergency PIN (4–8 digits)") },
                            leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                            singleLine = true
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Face, null, tint = Color(0xFF65D6FF))
                            Spacer(Modifier.width(8.dp))
                            Text("Live face + eyes-open + blink challenge", color = Color.White, fontSize = 13.sp)
                        }
                        Button(
                            onClick = {
                                if (pin.length < 4) status = "Set an emergency PIN with 4–8 digits first"
                                else {
                                    prefs.edit().putInt("hour", hour).putInt("minute", minute).apply()
                                    if (Build.VERSION.SDK_INT >= 31 &&
                                        !getSystemService(android.app.AlarmManager::class.java).canScheduleExactAlarms()) {
                                        status = "Allow Alarms & reminders, then tap SET DAILY ALARM again"
                                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                                    } else {
                                        val at = AlarmScheduler.scheduleDaily(this@MainActivity, hour, minute)
                                        status = "Alarm set for " + SimpleDateFormat("EEE, h:mm a", Locale.getDefault()).format(at)
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp)
                        ) { Text("SET DAILY ALARM") }
                        OutlinedButton(onClick = {
                            AlarmScheduler.cancel(this@MainActivity)
                            status = "Alarm cancelled"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Cancel alarm") }
                        Text(status, color = Color(0xFF65D6FF), fontSize = 13.sp)
                        Text("FaceLock Alarm • V1 • Face data stays on device", color = Color(0xFF71869E), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
